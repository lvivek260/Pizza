//
//  PizzaApp.swift
//  Pizza
//
//  Created by Vivek Lokhande on 15/02/25.
//

import SwiftUI

@main
struct PizzaApp: App {
    var body: some Scene {
        WindowGroup {
            HomeView()
        }
    }
}
