//
//  SelectedPizzaSize.swift
//  Pizza
//
//  Created by Vivek Lokhande on 15/02/25.
//

import Foundation

enum SelectedPizzaSize: CGFloat {
    case small
    case medium
    case large
    
    func getScale() -> CGFloat {
        return switch self {
        case .small : 0.8
        case .medium: 1.0
        case .large : 1.2
        }
    }
}
