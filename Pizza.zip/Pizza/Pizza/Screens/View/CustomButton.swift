//
//  CustomNavigationButton.swift
//  Pizza
//
//  Created by Vivek Lokhande on 15/02/25.
//

import SwiftUI

struct CustomButton: View {
    let image: ImageResource
    let action : ()-> Void
    
    var body: some View {
        Button(action: action) {
            ZStack {
                Circle()
                    .frame(width: 48, height: 48)
                    .tint(.white)
                    .shadow(color: .gray.opacity(0.4), radius: 5)
                Image(image)
            }
        }
    }
}
