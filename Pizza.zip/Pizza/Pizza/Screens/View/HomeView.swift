//
//  HomeView.swift
//  Pizza
//
//  Created by Vivek Lokhande on 15/02/25.
//

import SwiftUI

struct HomeView: View {
    @State var selectedIndex = 0
    @State var selectedPizzaSize: SelectedPizzaSize = .medium
    @State var isZooming = false
    @Namespace private var animationNamespace
    let pizzas: [String] = ["pizza1", "pizza2", "pizza3"]
    
    var body: some View {
        NavigationStack {
            ZStack {
                ZStack {
                    contentView
                    VStack {
                        headerView
                        Spacer().frame(height: 50)
                        PizzaBannerView(
                            pizzas: pizzas,
                            selectedIndex: $selectedIndex,
                            pizzaSize: $selectedPizzaSize,
                            isZooming: $isZooming,
                            animationNamespace: animationNamespace
                        )
                        Spacer()
                    }
                }
                .ignoresSafeArea()
                
                if isZooming {
                    ZoomImageView(imageName: pizzas[selectedIndex], animationNamespace: animationNamespace, isZooming: $isZooming)
                        .transition(.identity)
                        .background(Color.black.opacity(0.8))
                        .zIndex(1)
                }
            }
            
        }
    }
    
    private var headerView: some View {
        VStack {
            HStack {
                CustomButton(image: .back) {
                    
                }
                Spacer()
                VStack {
                    Text("Pizzas")
                        .font(.system(size: 16, weight: .light))
                    Text("Midnight Harvest")
                        .font(.system(size: 24, weight: .medium))
                }
                Spacer()
                CustomButton(image: .iconFav) {
                    
                }
            }
            .padding(.horizontal, 24)
                .padding(.top, UIApplication.shared.safeAreaTopInset)
        }
    }
    
    private var contentView: some View {
        VStack {
            circleBackground
            VStack(spacing: 20) {
                pizzaSizeView
                    .padding(.top, -85)
                detailText
            }
            Spacer()
            footerView
            Spacer()
        }
    }
   
    private var circleBackground: some View {
        Circle()
            .foregroundStyle(.highlight)
            .padding(.top, -83)
            .padding(.horizontal, -116)

    }
    
    private var pizzaSizeView: some View {
        HStack(alignment: .center, spacing: 24) {
            SizeSelectionButton(selectedPizzaSize: $selectedPizzaSize, mySize: .small, title: "S")
            .padding(.top, 16)
            
            VStack(alignment: .center) {
                Image(.banana)
                SizeSelectionButton(selectedPizzaSize: $selectedPizzaSize, mySize: .medium, title: "M")
                .padding(.top, -16)
            }
            
            SizeSelectionButton(selectedPizzaSize: $selectedPizzaSize, mySize: .large, title: "L")
            .padding(.top, 16)
        }
    }
    
    private var detailText: some View {
        Text("This pizza celebrates the rich and bold flavors of black olives paired with a medley of cheeses. The deep, earthy taste of black olives harmonizes beautifully with the creamy, melted cheeses.")
            .font(.system(size: 14))
            .padding(.horizontal, 30)
            .lineSpacing(4)
    }
    
    
    private var footerView: some View {
        HStack {
            minusPlusButtonView
            Spacer()
            priceTextView
            Spacer()
            addButton
        }
        .padding(.horizontal, 24)
    }
    
    private var minusPlusButtonView: some View {
        HStack(spacing: 20) {
            CustomButton(image: .plus){
                
            }
            
            Text("1")
                .foregroundStyle(.black)
                .font(.system(size: 24, weight: .heavy))
            
            CustomButton(image: .minus){
                
            }
        }
        .background(
            Color.highlight.clipShape(.capsule)
        )
    }
    
    private var priceTextView: some View {
        Text("$17.99")
            .font(.system(size: 24, weight: .heavy))
    }
    
    private var addButton: some View {
        Button(action: {
            
        }, label: {
            Text("Add")
                .font(.system(size: 24, weight: .heavy))
                .padding(12)
                .foregroundStyle(.white)
                .background(.accent)
                .clipShape(.capsule)
        })
    }
}

#Preview {
    HomeView()
}

