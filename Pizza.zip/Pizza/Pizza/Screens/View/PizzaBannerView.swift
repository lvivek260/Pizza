//
//  PizzaBannerView.swift
//  Pizza
//
//  Created by Vivek Lokhande on 15/02/25.
//

import SwiftUI

struct PizzaBannerView: View {
    let pizzas: [String]
    @Binding var selectedIndex: Int
    @Binding var pizzaSize: SelectedPizzaSize
    @Binding var isZooming: Bool
    var animationNamespace: Namespace.ID

    private let cardWidth: CGFloat = 240
    private let smallWidth: CGFloat = 80
    private let dragThreshold: CGFloat = 30

    var body: some View {
        GeometryReader { geometry in
            let screenWidth = geometry.size.width
            let spacing = (screenWidth - (cardWidth * pizzaSize.getScale() + smallWidth)) / 2
            let padding = (spacing + smallWidth * 0.5)

            ScrollViewReader { scrollView in
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(alignment: .center, spacing: spacing) {
                        ForEach(pizzas.indices, id: \.self) { index in
                            pizzaCell(index: index, geometry: geometry)
                        }
                    }
                    .frame(height: SelectedPizzaSize.large.getScale() * cardWidth)
                    .padding(.leading, selectedIndex == 0 ?  padding : 0)
                    .padding(.trailing, (selectedIndex == pizzas.count-1) ? padding : 0)
                    .gesture(dragGesture(scrollView: scrollView))
                }
                .scrollDisabled(true)
            }
        }
    }

    /// Generates the pizza cell with correct size based on selection
    private func pizzaCell(index: Int, geometry: GeometryProxy) -> some View {
        let size = (selectedIndex == index) ? (cardWidth * pizzaSize.getScale()) : smallWidth
        
        return Image(pizzas[index])
            .resizable()
            .scaledToFit()
            .frame(width: size, height: size)
            .animation(.bouncy, value: selectedIndex)
            .id(index)
            .matchedGeometryEffect(id: pizzas[index], in: animationNamespace)
            .onTapGesture {
                withAnimation(.spring(response: 0.4, dampingFraction: 0.6)) {
                    isZooming.toggle()
                }
            }
    }

    /// Handles swipe gesture to update selected index
    private func dragGesture(scrollView: ScrollViewProxy) -> some Gesture {
        DragGesture()
            .onEnded { value in
                if value.translation.width < -dragThreshold, selectedIndex < pizzas.count - 1 {
                    selectedIndex += 1  // Swipe left
                } else if value.translation.width > dragThreshold, selectedIndex > 0 {
                    selectedIndex -= 1  // Swipe right
                }

                // Scroll to selected index
                withAnimation {
                    scrollView.scrollTo(selectedIndex, anchor: .center)
                }
            }
    }
}
