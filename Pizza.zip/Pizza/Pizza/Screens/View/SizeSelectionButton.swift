//
//  SizeSelectionButton.swift
//  Pizza
//
//  Created by Vivek Lokhande on 15/02/25.
//

import SwiftUI

struct SizeSelectionButton: View {
    @Binding var selectedPizzaSize: SelectedPizzaSize
    var mySize: SelectedPizzaSize
    var title: String
    
    var body: some View {
        Button(action: {
            withAnimation(.spring(response: 0.3, dampingFraction: 0.4)) {
                selectedPizzaSize = mySize
            }
        }) {
            ZStack {
                Circle()
                    .frame(width: 48, height: 48)
                    .tint(isSelected ? .black : .white)
                    .shadow(color: .gray.opacity(0.4), radius: 5)
                Text(title)
                    .foregroundStyle(isSelected ? .white : .black)
                    .font(.system(size: 18, weight: .semibold))
            }
        }
    }
    
    private var isSelected: Bool {
        mySize == selectedPizzaSize
    }
}
