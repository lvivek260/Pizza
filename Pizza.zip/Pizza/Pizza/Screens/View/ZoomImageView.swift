//
//  ZoomImageView.swift
//  Pizza
//
//  Created by Vivek Lokhande on 16/02/25.
//

import SwiftUI

struct ZoomImageView: View {
    let imageName: String
    var animationNamespace: Namespace.ID
    @Binding var isZooming: Bool
    
    var body: some View {
       Image(imageName)
            .resizable()
            .scaledToFill()
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .matchedGeometryEffect(id: imageName, in: animationNamespace)
            .onTapGesture {
                withAnimation(.spring(response: 0.4, dampingFraction: 0.6)) {
                    isZooming = false
                }
            }
    }
}
