//
//  UIApplication.swift
//  Pizza
//
//  Created by Vivek Lokhande on 15/02/25.
//


import SwiftUI

extension UIApplication {
    var safeAreaTopInset: CGFloat {
        let keyWindow = connectedScenes
            .compactMap { $0 as? UIWindowScene }
            .flatMap { $0.windows }
            .first { $0.isKeyWindow }
        
        return keyWindow?.safeAreaInsets.top ?? 0
    }
}
